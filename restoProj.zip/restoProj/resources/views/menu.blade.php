@extends('layout/navlayout')

@section('content')
   

<div class=" container">
    <div class="row">
        <div class="container">
            <div class="row">
                <div class="col" style="width: 18rem; margin-top: 50px;" style="width: 286.992; height: 143.484;">
                    <center>
                    <div class="card">
                        <img src="Images/table2.jpg">
                        <div class="card-body">
                            <center>
                            <p class="card-text"><strong>1-2 PERSONS ₱399.OO</strong></p>
                            
                            </center>
                        </div>
                    </div>
                    <center>
                </div>

                <div class="col" style="margin-top: 50px;">
                    <center>
                    <div class="card" >
                        <img src="Images/table8.jpg" class="card-img-top" alt="...">
                        <div class="card-body">
                            <center>
                            <p class="card-text"><strong>2-4 PERSONS ₱599.OO</strong></p>
                                <div class="container ">
                                    
                            </center>
                        </div>
                    </div>
                    <center>
                </div>



                <div class=" container"></div>
                    <div class="row">
                        <div class="container">
                            <div class="row">
                                <div class="col" style="width: 18rem; margin-top: 50px;" style="width: 286.992; height: 143.484;">
                                    <center>
                                    <div class="card">
                                        <img src="Images/table10.jpg">
                                        <div class="card-body">
                                            <center>
                                            <p class="card-text"><strong>5-6 PERSONS ₱799.OO</strong></p>
                                            
                                            </center>
                                        </div>
                                    </div>
                                    <center>
                                </div>

                                <div class="col" style="margin-top: 50px;">
                                    <center>
                                    <div class="card" >
                                        <img src="Images/table11.jpg" class="card-img-top" alt="...">
                                        <div class="card-body">
                                            <center>
                                            <p class="card-text"><strong>7-8 PERSONS ₱999.OO</strong></p>

                                            </center>
                                        </div>
                                    </div>
                                    <center>
                                </div>

               

</div>
        
</body>
</html>
@endsection
<style>
  body{
            background:rgba(0,0,0,0.7) url(images/mm.jpg);
            background-size: cover;
            background-blend-mode: darken;
            background-attachment: fixed;
            background-repeat: no-repeat;
            background-position: center;
        }
        
</style>