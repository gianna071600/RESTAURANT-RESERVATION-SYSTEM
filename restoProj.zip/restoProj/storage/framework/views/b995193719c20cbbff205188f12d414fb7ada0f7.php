<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> CREATE RESERVATIONS </title>
</head>
<center>
<h1> CREATE RESERVATIONS </h1>
<nav>
<ul>
      <a href="<?php echo e(route('dashboard')); ?>">DASHBOARD ||</a>
      <a href="<?php echo e(route('reservations')); ?>">RESERVATIONS ||</a>
      <a href="<?php echo e(route('createreservations')); ?>">CREATE RESERVATIONS ||</a>
      <a href="<?php echo e(route('registercustomer')); ?>">REGISTER CUSTOMER ||</a>
      <a href="<?php echo e(route('customerlist')); ?>">CUSTOMER LIST ||</a>
      <a href="<?php echo e(route('reservationhistory')); ?>">RESERVATION HISTORY ||</a>
      <a href="<?php echo e(route('menu')); ?>">MENU ||</a>
      <a href="<?php echo e(route('logout')); ?>">LOGOUT</a>
</ul>
</nav>
</center>
<body style="background-color: gray;">
<center>
<h1> Resto Reservation Create Reservation</h1>
<form action="<?php echo e(route('issuereservation')); ?>" method="any">
        <?php echo csrf_field(); ?> 
            <div>
                <label>Customer's Name: </label>
                <select class="inputs" name="customerid" required>
                    <option value="">Select Customer</option>
                        <?php $__currentLoopData = $tblcustomers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tblcustomers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value='<?php echo e($tblcustomers->Cust_id); ?>'><?php echo e($tblcustomers->cust_Fname); ?> <?php echo e($tblcustomers->cust_Lname); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <h1> </h1>
            <div>
                <label> Reservation Event: </label>
                <input class="inputs" type="text" name="reservationevent" class="form-control" value="" placeholder="Reservation Event.." required>
            </div>
            <h1> </h1>
            <div>
                <label> No_of_Person: </label>
                <input class="inputs" type="number" name="nopersons" class="form-control" value="" placeholder="Number of Attendees.." required>
            </div>
            <h1> </h1>
            <div>
                <label>Reservation Date and Time: </label>
                <input type="datetime-local" class="inputs" name="datetime" min="<?php echo date("%Y-%m-%dT%H:%M:%S",strtotime("+0 day")); ?>" required>
            </div>
            <h1> </h1>
            <div>
                <label> Total Price of Orders: </label>
                <input class="inputs" type="number" name="totalamount" class="form-control" value="" placeholder="Total Amount.." required>
            </div>
            <h1> </h1>
            <input class="button" type="submit" name="submit" class="btn btn-danger" value="Create Reservation" required>
            </form>
</center>
</body>
</html>

<style>

</style><?php /**PATH C:\Users\Henz Montera\Desktop\Patrick Laravel\HenzResto\restoProj\resources\views/createreservations.blade.php ENDPATH**/ ?>