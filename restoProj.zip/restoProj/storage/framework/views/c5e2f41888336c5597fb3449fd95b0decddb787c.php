<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DASHBOARD</title>
</head>
<center>
<h1> DASHBOARD </h1>
<nav>
<ul>
      <a href="<?php echo e(route('dashboard')); ?>">DASHBOARD ||</a>
      <a href="<?php echo e(route('reservations')); ?>">RESERVATIONS ||</a>
      <a href="<?php echo e(route('createreservations')); ?>">CREATE RESERVATIONS ||</a>
      <a href="<?php echo e(route('registercustomer')); ?>">REGISTER CUSTOMER ||</a>
      <a href="<?php echo e(route('customerlist')); ?>">CUSTOMER LIST ||</a>
      <a href="<?php echo e(route('reservationhistory')); ?>">RESERVATION HISTORY ||</a>
      <a href="<?php echo e(route('menu')); ?>">MENU ||</a>
      <a href="<?php echo e(route('logout')); ?>">LOGOUT</a>
</ul>
</nav>
</center>
<body style="background-color: gray;">
<center>
<div class="flex-container">
        <div class="card">
        <h1> Active <br> Reservations </h1>
        <h1> x<?php echo e($reservationactivecount); ?> </h1>
        </div>
        <div class="card">
        <h1> Not Active <br> Reservations </h1>
        <h1> x<?php echo e($reservationnotactivecount); ?> </h1>
        </div>
        <div class="card">
        <h1> Active <br> Customers </h1>
        <h1> x<?php echo e($customeractivecount); ?> </h1>
        </div>
        <div class="card">
        <h1> Not Active <br> Customers </h1>
        <h1> x<?php echo e($customernotactivecount); ?> </h1>
        </div>
      </div> 
      
      <div class="flex-container">
        <div class="card">
        <h1> Active <br> Payments </h1>
        <h1> x<?php echo e($paymentsactivecount); ?> </h1>
        </div>
        <div class="card">
        <h1> Not Active <br> Payments </h1>
        <h1> x<?php echo e($paymentsnotactivecount); ?> </h1>
        </div>
        <div class="card">
        <h1> Active <br> Cashiers </h1>
        <h1> x<?php echo e($cashiersactivecount); ?> </h1>
        </div>
        <div class="card">
        <h1> Not Active <br> Cashiers </h1>
        <h1> x<?php echo e($cashiersnotactivecount); ?> </h1>
        </div>
      </div>
</center>
</body>
</html>

<style>
.flex-container {
  display: inline-flex;
}
.card > h1{
  font-family: 'Arial';
  font-weight: bold;
  color: white;
  text-shadow: 0.5px 0.5px rgba(0,0,0,0.5);
}
div.card {
    flex-direction: column;
}
.flex-container > div {
  background-color: #A73062;
  margin: 10px;
  padding: 20px;
  font-size: 12px;
  border-radius: 5px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.5);
}
</style><?php /**PATH C:\Users\Henz Montera\Desktop\Patrick Laravel\HenzResto\restoProj\resources\views/dashboard.blade.php ENDPATH**/ ?>