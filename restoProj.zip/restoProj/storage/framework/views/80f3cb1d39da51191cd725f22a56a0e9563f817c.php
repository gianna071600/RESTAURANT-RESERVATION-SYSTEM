<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RESERVATIONS</title>
</head>
<center>
<h1> RESERVATIONS </h1>
<nav>
<ul>
      <a href="<?php echo e(route('dashboard')); ?>">DASHBOARD ||</a>
      <a href="<?php echo e(route('reservations')); ?>">RESERVATIONS ||</a>
      <a href="<?php echo e(route('createreservations')); ?>">CREATE RESERVATIONS ||</a>
      <a href="<?php echo e(route('registercustomer')); ?>">REGISTER CUSTOMER ||</a>
      <a href="<?php echo e(route('customerlist')); ?>">CUSTOMER LIST ||</a>
      <a href="<?php echo e(route('reservationhistory')); ?>">RESERVATION HISTORY ||</a>
      <a href="<?php echo e(route('menu')); ?>">MENU ||</a>
      <a href="<?php echo e(route('logout')); ?>">LOGOUT</a>
</ul>
</nav>
</center>
<body style="background-color: gray;">
<center>
<?php if(!empty($activereservations) && $activereservations->count()): ?>
<table class="table-sortable">
<thead>
  <tr>
    <th> Res_id </th>
    <th> Cust_id </th>
    <th> Payment_no </th>
    <th> C_id </th>
    <th> status </th>
    <th> Fullname </th>
    <th> Address </th>
    <th> Res_event </th>
    <th> Contact_no </th>
    <th> No_of_person </th>
    <th> Res_dateandtime </th>
    <th> created_at </th>
    <th> updated_at </th>
    <th> Delete </th>
  </tr>
  </thead>
  <?php $__currentLoopData = $activereservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tbody>
  <tr class="tablerow">
    <td><?php echo e($data->Res_id); ?></td>
    <td><?php echo e($data->Cust_id); ?></td>
    <td><?php echo e($data->Payment_no); ?></td>
    <td><?php echo e($data->C_id); ?></td>
    <td><?php echo e($data->status); ?></td>
    <td><?php echo e($data->Fullname); ?></td>
    <td><?php echo e($data->Address); ?></td>
    <td><?php echo e($data->Res_event); ?></td>
    <td><?php echo e($data->Contact_no); ?></td>
    <td><?php echo e($data->No_of_person); ?></td>
    <td><?php echo e($data->Res_dateandtime); ?></td>
    <td><?php echo e($data->created_at); ?></td>
    <td><?php echo e($data->updated_at); ?></td>
    <td class="deletebutton">
      <form action="<?php echo e(route('deletereservation',$data->Res_id)); ?>" method="any" class="form-hidden">
        <button >Delete</button>
        <?php echo csrf_field(); ?>
      </form>
    </td>
  </tr>
  </tbody>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php else: ?>
  <div style="margin-top: 180px; font-family: Arial; font-weight: bold;">
                <tr>
                    <td classcolspan="10">There are no data.</td>
                </tr>
        </div>
  <?php endif; ?>
</table>
</center>
</body>
</html>

<style>
  table, th, td {
  border: 1px solid black;
  text-align:center;
  padding:5px;
  font-size:15px;
  font-family: 'Arial';
  font-weight: bold;
}
</style><?php /**PATH C:\Users\Henz Montera\Desktop\Patrick Laravel\HenzResto\restoProj\resources\views/reservations.blade.php ENDPATH**/ ?>