<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CUSTOMER LIST</title>
</head>
<center>
<h1> CUSTOMER LIST </h1>
<nav>
<ul>
      <a href="<?php echo e(route('dashboard')); ?>">DASHBOARD ||</a>
      <a href="<?php echo e(route('reservations')); ?>">RESERVATIONS ||</a>
      <a href="<?php echo e(route('createreservations')); ?>">CREATE RESERVATIONS ||</a>
      <a href="<?php echo e(route('registercustomer')); ?>">REGISTER CUSTOMER ||</a>
      <a href="<?php echo e(route('customerlist')); ?>">CUSTOMER LIST ||</a>
      <a href="<?php echo e(route('reservationhistory')); ?>">RESERVATION HISTORY ||</a>
      <a href="<?php echo e(route('menu')); ?>">MENU ||</a>
      <a href="<?php echo e(route('logout')); ?>">LOGOUT</a>
</ul>
</nav>
</center>
<body style="background-color: gray;">
<center>
<?php if(!empty($activecustomers) && $activecustomers->count()): ?>
<table class="table-sortable">
<thead>
  <tr>
    <th> Cust_id </th>
    <th> cust_Fname </th>
    <th> cust_Lname </th>
    <th> status </th>
    <th> cust_Address </th>
    <th> cust_Phone </th>
    <th> gender </th>
    <th> created_at </th>
    <th> updated_at </th>
    <th> Edit </th>
    <th> Delete </th>
  </tr>
  </thead>
  <?php $__currentLoopData = $activecustomers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tbody>
  <tr class="tablerow">
    <td><?php echo e($data->Cust_id); ?></td>
    <td><?php echo e($data->cust_Fname); ?></td>
    <td><?php echo e($data->cust_Lname); ?></td>
    <td><?php echo e($data->status); ?></td>
    <td><?php echo e($data->cust_Address); ?></td>
    <td><?php echo e($data->cust_Phone); ?></td>
    <td><?php echo e($data->gender); ?></td>
    <td><?php echo e($data->created_at); ?></td>
    <td><?php echo e($data->updated_at); ?></td>
    <td class="editbutton">
      <form action="<?php echo e(route('editcustomerinfo',$data->Cust_id)); ?>" method="any" class="form-hidden">
        <button>Edit</button>
        <?php echo csrf_field(); ?>
      </form>
    </td>
    <td class="deletebutton">
      <form action="<?php echo e(route('deletecustomerinfo',$data->Cust_id)); ?>" method="any" class="form-hidden">
        <button >Delete</button>
        <?php echo csrf_field(); ?>
      </form>
    </td>
  </tr>
  </tbody>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php else: ?>
  <div style="margin-top: 180px; font-family: Arial; font-weight: bold;">
                <tr>
                    <td classcolspan="10">There are no data.</td>
                </tr>
        </div>
  <?php endif; ?>
</table>
</center>
</body>
</html>

<style>
  table, th, td {
  border: 1px solid black;
  text-align:center;
  padding:5px;
  font-size:15px;
  font-family: 'Arial';
  font-weight: bold;
}
</style><?php /**PATH C:\Users\Henz Montera\Desktop\Patrick Laravel\HenzResto\restoProj\resources\views/customerlist.blade.php ENDPATH**/ ?>