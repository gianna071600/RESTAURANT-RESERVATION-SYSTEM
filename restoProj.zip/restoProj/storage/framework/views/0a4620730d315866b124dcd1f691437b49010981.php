<!DOCTYPE html>
<html lang="en">
<link rel="shortcut icon" href="<?php echo e(asset('Image/libraryicon.ico')); ?>">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> LOGIN RESTO RESERVATION </title>
</head>
<center>
<body style="margin-top:200px; background-color: gray;">
    <h1> Resto Reservation Login</h1>
        <form action="<?php echo e(route('loginchecker')); ?>" method="any">
            <?php echo csrf_field(); ?> 
            <div>
                <label> USERNAME: </label>
                <input class="inputs" type="text" name="username" class="form-control" value="<?php echo e(old('username')); ?>" placeholder="Your Username.." required>
            </div>
            <h1> </h1>
            <div>
                <label> PASSWORD: </label>
                <input class="inputs" type="password" name="password" class="form-control" value="" placeholder="Your Password.." required>
            </div>
            <input class="button" style="margin-top: 20px;" type="submit" name="login" class="btn btn-danger" value="Login"/>
        </form>
        <h1></h1>
        <a> Don't Have an Account? <a class="link" href="<?php echo e(route('signup')); ?>"> Sign Up </a></a>
</body>
</center>
</html><?php /**PATH C:\Users\Henz Montera\Desktop\Patrick Laravel\HenzResto\restoProj\resources\views/login.blade.php ENDPATH**/ ?>