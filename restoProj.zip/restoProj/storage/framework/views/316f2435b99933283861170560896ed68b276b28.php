

<?php $__env->startSection('content'); ?>


<div class="container"  >

      <div class="form-group" style="margin-right: 70px; margin-left: 40px; margin-top: 50px;" >
          <table class="table" style="color:white;">
              <thread>
              <tr>
                <th> Cust_id </th>
                <th> cust_Fname </th>
                <th> cust_Lname </th>
                <th> status </th>
                <th> cust_Address </th>
                <th> cust_Phone </th> 
                <th> gender </th>
                <th> created_at </th>
                <th> updated_at </th>
                <th> Edit </th>
                <th> Delete </th>
              </tr>
              </thread>

              <?php $__empty_1 = true; $__currentLoopData = $activecustomers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tbody>
                <tr class="tablerow">
                  <td><?php echo e($data->Cust_id); ?></td>
                  <td><?php echo e($data->cust_Fname); ?></td>
                  <td><?php echo e($data->cust_Lname); ?></td>
                  <td><?php echo e($data->status); ?></td>
                  <td><?php echo e($data->cust_Address); ?></td>
                  <td><?php echo e($data->cust_Phone); ?></td>
                  <td><?php echo e($data->gender); ?></td>
                  <td><?php echo e($data->created_at); ?></td>
                  <td><?php echo e($data->updated_at); ?></td>
                  <td class="editbutton">
                    <form action="<?php echo e(route('editcustomerinfo',$data->Cust_id)); ?>" method="any" class="form-hidden">
                      <button class="btn btn-primary">Edit</button>
                      <?php echo csrf_field(); ?>
                    </form>
                  </td>
                  <td class="deletebutton">
                    <form action="<?php echo e(route('deletecustomerinfo',$data->Cust_id)); ?>" method="any" class="form-hidden">
                      <button class="btn btn-danger"> Delete </button>
                      <?php echo csrf_field(); ?>
                    </form>
                  </td>
                </tr>
                </tbody>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div style="margin-top: 180px; font-family: Arial; font-weight: bold;">
                      <tr>
                          <td classcolspan="10">There are no data.</td>
                      </tr>
                </div>
                <?php endif; ?>

            
</table>

    </body>
<?php $__env->stopSection(); ?>
<style>
  body{
            background:rgba(0,0,0,0.7) url(images/mm.jpg);
            background-size: cover;
            background-blend-mode: darken;
            background-attachment: fixed;
            background-repeat: no-repeat;
            background-position: center;
  }
      
</style>
<?php echo $__env->make('layout/navlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\restoProj\resources\views/customerlist.blade.php ENDPATH**/ ?>