<?php $__env->startSection('content'); ?>
<center>
<label style="font-size: 70px"> Resto Reservation Login</label>
    <div class="container-fluid"></div>
      <div class="wrapper">
               <div class="container">
                    <form action="<?php echo e(route('loginchecker')); ?>" method="any">
                        <div class="username">
                            <p style="font-size: 35px" class="text-left"> USERNAME: </p>
                            <input id="username"style="font-size: 35px" type="text" name="username" class="form-control" value="<?php echo e(old('username')); ?>" placeholder="Your Username.." required>
                            <?php if($errors->has('username')): ?>
                                <span class="text-danger"><?php echo e($errors->first('username')); ?></span>
                            <?php endif; ?>
                        </div>

                        <div class="password">
                            <p style="font-size: 35px"class="text-left"> PASSWORD: </p>
                            <input id="password" style="font-size: 35px" type="password" name="password" class="form-control" value="" placeholder="Your Password.." required>
                            <?php if($errors->has('password')): ?>
                                <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                            <?php endif; ?>
                        </div>

                        <div class="button">
                            <button type="submit" class="w-100 btn btn-lg btn-outline-success col"> Login</button>
                        </div>

                        <div class="DontAcc">
                            <a style="color:white;"> Don't Have an Account? <a class="link" style="color:skyblue;" href="<?php echo e(route('signup')); ?>"> Sign Up </a></a>
                        </div>
                    </form>
               </div>
      </div>
    </div>
</center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\restoProj\resources\views/login.blade.php ENDPATH**/ ?>