<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EDIT CUSTOMER</title>
</head>
<center>
<h1> EDIT CUSTOMER </h1>
<nav>
<ul>
      <a href="<?php echo e(route('dashboard')); ?>">DASHBOARD ||</a>
      <a href="<?php echo e(route('reservations')); ?>">RESERVATIONS ||</a>
      <a href="<?php echo e(route('createreservations')); ?>">CREATE RESERVATIONS ||</a>
      <a href="<?php echo e(route('registercustomer')); ?>">REGISTER CUSTOMER ||</a>
      <a href="<?php echo e(route('customerlist')); ?>">CUSTOMER LIST ||</a>
      <a href="<?php echo e(route('reservationhistory')); ?>">RESERVATION HISTORY ||</a>
      <a href="<?php echo e(route('menu')); ?>">MENU ||</a>
      <a href="<?php echo e(route('logout')); ?>">LOGOUT</a>
</ul>
</nav>
</center>
<body>
<center>
<h1> Resto Reservation Customer Registration</h1>
<form action="<?php echo e(route('customeredited')); ?>" method="any">
            <?php echo csrf_field(); ?> 
            <div>
                <label> Customer ID: </label>
                <input class="inputs" type="text" name="customerid" class="form-control" value="<?php echo e($Cust_id); ?>" placeholder="First Name.." readonly>
            </div>
            <h1> </h1>
            <div>
                <label> First Name: </label>
                <input class="inputs" type="text" name="fname" class="form-control" value="<?php echo e($cust_Fname); ?>" placeholder="First Name.." required>
            </div>
            <h1> </h1>
            <div>
                <label> Last Name: </label>
                <input class="inputs" type="text" name="lname" class="form-control" value="<?php echo e($cust_Lname); ?>" placeholder="Last Name.." required>
            </div>
            <h1> </h1>
            <div>
                <label> Address: </label>
                <input class="inputs" type="text" name="address" class="form-control" value="<?php echo e($cust_Address); ?>" placeholder="Address.." required>
            </div>
            <h1> </h1>
            <div>
                <label> Phone Number: </label>
                <input class="inputs" type="text" name="phonenumber" class="form-control" value="<?php echo e($cust_Phone); ?>" placeholder="Phone Number.." required>
            </div>
            <h1> </h1>
            <label for="gender">Gender:</label>
                <select id="gender" name="gender" required>
                    <option value="<?php echo e($gender); ?>"><?php echo e($gender); ?></option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                </select>
            <h1> </h1>
            <input class="button" style="margin-top: 20px;" type="submit" name="signup" class="btn btn-danger" value="Update"/>
        </form>
</center>
</body>
</html>

<style>

</style><?php /**PATH C:\Users\Henz Montera\Desktop\Patrick Laravel\HenzResto\restoProj\resources\views/customer/edit.blade.php ENDPATH**/ ?>