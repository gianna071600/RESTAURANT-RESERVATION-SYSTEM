

<?php $__env->startSection('content'); ?>

<center>
<div class="card" style="margin-top:40px">
    <div class="card-header row ">
        <label class="text-left col font-weight-bold " style="font-size:22px">Resto Reservation Create Reservation</>
    </div>
</div> 
<div class="card">
    <div class="card-body">
        <form action="<?php echo e(route('issuereservation')); ?>" method="any">
            <?php echo csrf_field(); ?> 

                <div class="container">
                    <div class="row">
                        <label for="reservationevent" class="col text-md-left" style="font-size: 20px font-weight-bold">Customer's Name:</label>
                    </div>
                    <div class="row">
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <label class="input-group-text" for="inputGroupSelect01">Options</label>
                            </div>
                            <select class="custom-select" id="inputGroupSelect01" name="customerid" required>
                            <option value="">Select Customer</option>
                                <?php $__currentLoopData = $tblcustomers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tblcustomers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value='<?php echo e($tblcustomers->Cust_id); ?>'><?php echo e($tblcustomers->cust_Fname); ?> <?php echo e($tblcustomers->cust_Lname); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('reservationevent')): ?>
                            <span class="text-danger"><?php echo e($errors->first('reservationevent')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <h1> </h1>

                <div class="container">
                    <div class="row">
                        <label for="reservationevent" class="col text-md-left font-weight-bold" style="font-size: 20px">Reservation Event:</label>
                    </div>
                    <div class="row">
                    <input type="text" id="reservationevent" class="form-control" name="reservationevent" placeholder="Reservation Event.." value="" required>
                        <?php if($errors->has('reservationevent')): ?>
                            <span class="text-danger"><?php echo e($errors->first('reservationevent')); ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <h1> </h1>

                <div class="container">
                    <div class="row">
                        <label for="nopersons" class="col text-md-left font-weight-bold" style="font-size: 20px">No of Person:</label>
                    </div>
                    <div class="row">
                        <input type="number" id="nopersons" class="form-control col" name="nopersons" placeholder="Number of Attendees.." value="" required>
                        <?php if($errors->has('nopersons')): ?>
                            <span class="text-danger"><?php echo e($errors->first('nopersons')); ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <h1> </h1>

                <div class="container">
                    <div class="row">
                        <label for="datetime" class="col text-md-left font-weight-bold" style="font-size: 20px">Reservation Date and Time:</label>
                    </div>
                    <div class="row">
                        <input type="datetime-local" id="datetime" class="form-control col " name="datetime"min="<?php echo date("%Y-%m-%dT%H:%M:%S",strtotime("+0 day")); ?>" required>
                        <?php if($errors->has('datetime')): ?>
                            <span class="text-danger"><?php echo e($errors->first('datetime')); ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <h1> </h1>

                <div class="container">
                    <div class="row">
                        <label for="totalamount" class="col text-md-left font-weight-bold" style="font-size: 20px">Total Price of Orders:</label>
                    </div>
                    <div class="row">
                    <input type="number" name="totalamount" class="form-control col" value="" placeholder="Total Amount.." required>
                        <?php if($errors->has('totalamount')): ?>
                            <span class="text-danger"><?php echo e($errors->first('totalamount')); ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <h1> </h1>

                <input style="margin-top:30px;"class="w-100 btn btn-outline-success" type="submit" name="submit" value="Create Reservation" required></style>
        </form>
    </div>
</div>
</center>
<?php $__env->stopSection(); ?>
<style>
  body{
            background:rgba(0,0,0,0.7) url(images/mm.jpg);
            background-size: cover;
            background-blend-mode: darken;
            background-attachment: fixed;
            background-repeat: no-repeat;
            background-position: center;
        }
       
</style>

<?php echo $__env->make('layout/navlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\restoProj\resources\views/createreservations.blade.php ENDPATH**/ ?>