

<?php $__env->startSection('content'); ?>
<center>
<h1> Resto Reservation Signup</h1>
    <div class="container-sm">
    <form action="<?php echo e(route('signupchecker')); ?>" method="any">
            <?php echo csrf_field(); ?> 
            <div class="fname">
                <p style="font-size: 20px" class="text-left"> First Name: </p>
                <input id="fname"style="font-size: 16px" type="text" name="fname" class="form-control" value="<?php echo e(old('fname')); ?>" placeholder="First Name.." required autofocus>
                <?php if($errors->has('fname')): ?>
                    <span class="text-danger"><?php echo e($errors->first('fname')); ?></span>
                <?php endif; ?>
            </div>

            <div class="lname">
                <p style="font-size: 20px" class="text-left"> Last Name: </p>
                <input id="lname"style="font-size: 16px" type="text" name="lname" class="form-control" value="<?php echo e(old('lname')); ?>" placeholder="Last Name.." required>
                <?php if($errors->has('lname')): ?>
                    <span class="text-danger"><?php echo e($errors->first('lname')); ?></span>
                <?php endif; ?>
            </div>

            <div class="username">
                <p style="font-size: 20px" class="text-left"> User Name: </p>
                <input id="username"style="font-size: 16px" type="text" name="username" class="form-control" value="<?php echo e(old('username')); ?>" placeholder="User Name.." required>
                <?php if($errors->has('username')): ?>
                    <span class="text-danger"><?php echo e($errors->first('username')); ?></span>
                <?php endif; ?>
            </div>

            <div class="password">
                <p style="font-size: 20px" class="text-left">Password: </p>
                <input id="password"style="font-size: 16px" type="password" name="password" class="form-control" value="<?php echo e(old('password')); ?>" placeholder="Password.." required>
                <?php if($errors->has('password')): ?>
                    <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                <?php endif; ?>
            </div>


            <div class="confirmpassword">
                <p style="font-size: 20px" class="text-left"> Confirm Password: </p>
                <input id="confirmpassword"style="font-size: 16px" type="password" name="confirmpassword" class="form-control" value="<?php echo e(old('confirmpassword')); ?>" placeholder="Confirm Password.." required>
                <?php if($errors->has('confirmpassword')): ?>
                    <span class="text-danger"><?php echo e($errors->first('confirmpassword')); ?></span>
                <?php endif; ?>
            </div>

            <div class="address">
                <p style="font-size: 20px" class="text-left"> Address: </p>
                <input id="address"style="font-size: 16px" type="text" name="address" class="form-control" value="<?php echo e(old('address')); ?>" placeholder="Address.." required>
                <?php if($errors->has('address')): ?>
                    <span class="text-danger"><?php echo e($errors->first('address')); ?></span>
                <?php endif; ?>
            </div>
            
            <div class="phonenumber">
                <p style="font-size: 20px" class="text-left"> Phone Number: </p>
                <input id="phonenumber"style="font-size: 16px" type="text" name="phonenumber" class="form-control" value="<?php echo e(old('phonenumber')); ?>" placeholder="Phone Number.." required>
                <?php if($errors->has('phonenumber')): ?>
                    <span class="text-danger"><?php echo e($errors->first('phonenumber')); ?></span>
                <?php endif; ?>
            </div>
            
            <div class="email">
                <p style="font-size: 20px" class="text-left"> Email: </p>
                <input id="email"style="font-size: 16px" type="text" name="email" class="form-control" value="<?php echo e(old('email')); ?>" placeholder="Email.." required>
                <?php if($errors->has('email')): ?>
                    <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                <?php endif; ?>
            </div>

            <div class="gender">
                <p style="font-size: 20px" class="text-left"> Gender: </p>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <label class="input-group-text" for="gender">Options</label>
                    </div>
                    <select name="gender" class="custom-select" id="gender">
                        <option selected>Select Gender..</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                    </select>
                </div>
            </div>
            <input style="margin-top: 20px;" type="submit" name="signup" class="btn btn-success" value="Sign-Up"/>
        </form>
       <div class="DontAcc">
            <a style="color:white; margin-top:20px;"> Already have an Account <a class="link" style="color:skyblue;" href="<?php echo e(route('login')); ?>"> Login Already! </a></a>
       </div>
    </div>
</center>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\restoProj\resources\views/signup.blade.php ENDPATH**/ ?>