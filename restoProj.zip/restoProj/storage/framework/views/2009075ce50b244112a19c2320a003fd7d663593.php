

<?php $__env->startSection('content'); ?>



<div class="container" style ="margin-top: 150px; padding: 5px;">
  <div class="row">
    <div class="col">
      <div class="card-deck" style="padding: 50px;" >
            <div class="card"  style="width: 30px; height: 150px;">
              <div class="card-body" style="margin-right: 40px;" >
              <center style="padding: 5px;">
                <h5> Active Reservations </h5>
                <h6> x<?php echo e($reservationactivecount); ?> </h6>
              </center>
              </div>
            </div>

            <div class="card">
              <div class="card-body">
              <center>
                <h5> Not Active Reservations </h5>
                <h6> x<?php echo e($reservationnotactivecount); ?> </h6>
              </center>
              </div>
            </div>

            <div class="card">
              <div class="card-body">
              <center>
                <h5> Active Customers </h5>
                <h6> x<?php echo e($customeractivecount); ?> </h6>
              </center>
              </div>
            </div>

            <div class="card">
              <div class="card-body">
              <center>
                <h5> Not Active Customers </h5>
                <h6> x<?php echo e($customernotactivecount); ?> </h6>
              </center>
              </div>
            </div>
        </div>
        

        <div class="col" style>
          <div class="card-deck">
            <div class="card" style="width: 30px; height: 150px;">
              <div class="card-body" style="margin-right: 40px; ">
              <center>
              <h5> Active Payments </h5>
              <h6> x<?php echo e($paymentsactivecount); ?> </h6>
              </center>
              </div>
            </div>

            <div class="card">
              <div class="card-body">
              <center>
              <h5> Not Active Payments </h5>
              <h6> x<?php echo e($paymentsnotactivecount); ?> </h6>
              </center>
              </div>
            </div>

            <div class="card">
              <div class="card-body">
              <center>
              <h5> Active Cashiers </h5>
              <h6> x<?php echo e($cashiersactivecount); ?> </h6>
              </center>
              </div>
            </div>

            <div class="card">
              <div class="card-body">
              <center>
              <h5> Not Active Cashiers </h5>
              <h6> x<?php echo e($cashiersnotactivecount); ?> </h6>
              </center>
              </div>
            </div>
        </div>
        </div>
    </div>
  </div>
</div>
</body>
</html>
<?php $__env->stopSection(); ?>
<style>
  body{
            background:rgba(0,0,0,0.7) url(images/mm.jpg);
            background-size: cover;
            background-blend-mode: darken;
            background-attachment: fixed;
            background-repeat: no-repeat;
            background-position: center;
        }
        
</style>
<?php echo $__env->make('layout/navlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\restoProj\resources\views/dashboard.blade.php ENDPATH**/ ?>